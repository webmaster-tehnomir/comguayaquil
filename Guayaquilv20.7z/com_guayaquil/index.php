<?php
namespace guayaquil;

define('GUAYAQUIL_DIR', __DIR__);

router::start();